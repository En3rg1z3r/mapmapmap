This is an example static folder for demonstration.

These files are not my own, and their respective licenses apply.

[Leaflet](https://github.com/Leaflet/Leaflet/blob/master/LICENSE)

[sql-js](https://github.com/alejandromav/sql-js/blob/master/LICENSE)

[Leaflet.TileLayer.MBTiles](https://gitlab.com/IvanSanchez/Leaflet.TileLayer.MBTiles/-/blob/master/LICENSE)

[Bootstrap](https://github.com/twbs/bootstrap/blob/master/LICENSE)
