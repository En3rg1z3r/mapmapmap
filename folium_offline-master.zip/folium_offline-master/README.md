## Usage

### folium_offline.py
Starter script to build offline maps with Folium.

### server.py
Python's simple HTTP Server ripped straight from the docs.

### build_simple_server.py
Use PyInstaller to package server.py for local use.
